#include <iostream>
using namespace std;

bool isEven(int x) {
    if (x % 2 = 0) {  // BUG
        return true;
    }
    return false;
}

int main() {
    cout << isEven(4) << endl;
}
